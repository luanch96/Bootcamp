import sys

args = sys.argv[1:]

if len(args) == 0:
    sys.exit()

args = " ".join(args)


def swap_case(letter):
    return letter.upper() if letter.islower() else letter.lower()


print("".join(map(swap_case, args[::-1])))
