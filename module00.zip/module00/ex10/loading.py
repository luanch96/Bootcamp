from time import sleep, time


def ft_progress(listy):
    t0 = time()
    for i, el in enumerate(listy):
        N = len(listy)
        progress = i / N
        elapsed_time = time() - t0
        if i == 0:
            # We cannot estimate the remaining time if no iteration has been done yet
            yield el
            continue
        eta = N * (elapsed_time / i) - elapsed_time
        equal_signs = int(progress * 100 // 5)  # It will increase every 5 iterations
        spaces = 20 - equal_signs
        # By using a carriage return at the start of the string, and ending the string
        # with an empty string instead of a newline, we can "edit" the current line
        print(
            f"""\rETA {eta:.2f}s [ {progress:.0%}]"""
            f"""[{equal_signs * '='}>{spaces * ' '}] {i+1}/{N} | elapsed time {elapsed_time:.2f}s""",
            end="",
        )
        yield el


listy = range(1000)
ret = 0
for elem in ft_progress(listy):
    ret += (elem + 3) % 5
    sleep(0.01)

print()
print(ret)


listy = range(3333)
ret = 0
for elem in ft_progress(listy):
    ret += elem
    sleep(0.005)
print()
print(ret)
