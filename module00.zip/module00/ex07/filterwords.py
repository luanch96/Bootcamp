import sys
import string

try:
    assert len(sys.argv) == 3, "ERROR"
    assert type(sys.argv[1]) == type("str"), "ERROR"
    assert sys.argv[2].isnumeric(), "ERROR"

    text = sys.argv[1]
    N = int(sys.argv[2])

    text = "".join([t for t in text if not (t in string.punctuation)])
    words = text.split(" ")
    print([w for w in words if len(w) > N])

except AssertionError as error:
    print(error)