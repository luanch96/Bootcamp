import sys
import string


def text_analyzer(text=None):
    """
    This function counts the number of upper characters, lower characters,
    punctuation and spaces in a given text."""
    if text is None or text == "":
        print("What is the text to analyze?")
        text = input()

    try:
        assert type(text) == type("str"), "argument is not a string"
    except AssertionError as error:
        print(f"AssertionError: {error}")
        return
    punctuation_chars = set(string.punctuation)

    # We could do it in one passing of the text, but we will keep
    # it simple now
    upper_letters = len(list(filter(lambda x: x.isupper(), text)))
    lower_letters = len(list(filter(lambda x: x.islower(), text)))
    punctuation_marks = len(list(filter(lambda x: x in punctuation_chars, text)))
    spaces = len(list(filter(lambda x: x == " ", text)))
    total = len(text)

    print(f"The text contains {total} character(s):")
    print(f"- {upper_letters} upper letter(s)")
    print(f"- {lower_letters} lower letter(s)")
    print(f"- {punctuation_marks} punctuation mark(s)")
    print(f"- {spaces} space(s)")


if __name__ == "__main__":
    if len(sys.argv) > 2:
        raise ValueError("Too many arguments provided")
    text = sys.argv[1] if len(sys.argv) == 2 else None
    text_analyzer(text)
