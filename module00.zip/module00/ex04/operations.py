import sys

try:
    assert len(sys.argv) <= 3, "too many arguments"
    if len(sys.argv) < 3:
        raise AttributeError("Usage: python operations.py <number1> <number2>\nExample:\n    python operations.py 10 3")
    assert sys.argv[1].isnumeric() and sys.argv[2].isnumeric(), "only integers"

    a = int(sys.argv[1])
    b = int(sys.argv[2])

    print(f"Sum:\t\t{a+b}")
    print(f"Difference:\t{a-b}")
    print(f"Product:\t{a*b}")
    if b != 0:
        print(f"Quotient:\t{a/b}")
        print(f"Remainder:\t{a%b}")
    else:
        print(f"Quotient:\tERROR (division by zero)")
        print(f"Remainder:\tERROR (modulo by zero)")

except AttributeError as error:
    print(error)
except AssertionError as error:
    print(f"AssertionError: {error}")