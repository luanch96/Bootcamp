import sys

if len(sys.argv) == 1:
    sys.exit()
try:
    assert len(sys.argv) == 2, "more than one argument are provided"

    arg = sys.argv[1]

    assert arg.isnumeric(), "argument is not an integer"
    arg = int(arg)

    if arg == 0:
        print("I'm Zero.")
    else: 
        even_odd = ["Even", "Odd"]
        print(f"I'm {even_odd[arg % 2]}.")

except AssertionError as error:
    print(f"AssertionError: {error}")
