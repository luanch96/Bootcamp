import sys
from string import ascii_letters, digits

try:
    if len(sys.argv) == 1:
        sys.exit()

    text = " ".join(sys.argv[1:])
    assert all([c in ascii_letters or c in digits or c == " " for c in text]), "ERROR"

    text = "".join([c.lower() for c in text])  # Set to lowercase

    mapping = {
        "a": ".-",
        "b": "-...",
        "c": "-.-.",
        "d": "-..",
        "e": ".",
        "f": "..-.",
        "g": "--.",
        "h": "....",
        "i": "..",
        "j": ".---",
        "k": "-.-",
        "l": ".-..",
        "m": "--",
        "n": "-.",
        "o": "---",
        "p": ".--.",
        "q": "--.-",
        "r": ".-.",
        "s": "...",
        "t": "-",
        "u": "..-",
        "v": "...-",
        "w": ".--",
        "x": "-..-",
        "y": "-.--",
        "z": "--..",
        "0": "-----",
        "1": ".----",
        "2": "..---",
        "3": "...--",
        "4": "....-",
        "5": ".....",
        "6": "-....",
        "7": "--...",
        "8": "---..",
        "9": "----.",
        " ": "/",
    }

    print(" ".join(map(lambda x: mapping[x], text)))

except AssertionError as error:
    print(error)
