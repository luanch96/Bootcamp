def make_recipe(ingredients, meal, prep_time):
    return {"ingredients": ingredients, "meal": meal, "prep_time": prep_time}


cookbook = {
    "sandwich": make_recipe(["ham", "bread", "cheese", "tomatoes"], "lunch", 10),
    "cake": make_recipe(["flour", "sugar", "eggs"], "dessert", 60),
    "salad": make_recipe(["avocado", "arugula", "tomatoes", "spinach"], "lunch", 15),
}


def add_recipe(name, ingredients, meal, prep_time):
    cookbook[name] = make_recipe(ingredients, meal, prep_time)


def input_and_add_recipe():
    print("Enter a name")
    name = input()
    print("Enter ingredients")
    ingredients = []
    ingr = input()
    while ingr != "":
        ingredients.append(ingr)
        ingr = input()
    print("Enter a meal type")
    meal = input()
    print("Enter a preparation time")
    prep_time = int(input())
    add_recipe(name, ingredients, meal, prep_time)


def del_recipe(key):
    if key is None:
        print("What recipe do you want to delete?")
        key = input()
    if not (key in cookbook):
        print("That recipe does not exist.")
        return
    del cookbook[key]


def print_recipe(recipe):
    if recipe is None:
        print("Please enter a recipe name to get its details")
        recipe = input()
    if not (recipe in cookbook):
        print("That recipe does not exist.")
        return
    print()
    print(f"Recipe for {recipe}:")
    recipe = cookbook[recipe]
    print(f"  Ingredients list: {recipe['ingredients']}")
    print(f"  To be eaten for {recipe['meal']}.")
    print(f"  Takes {recipe['prep_time']} minutes of cooking.")
    print()


option = 0

available_options = """List of available option:
  1: Add a recipe
  2: Delete a recipe
  3: Print a recipe
  4: Print the cookbook
  5: Quit
"""

print("Welcome to the Python Cookbook !")
print(available_options)

while option != 5:
    print("Please select an option:")
    option = input()
    if not option.isnumeric():
        print("Sorry, this option does not exist.")
        print(available_options)
        continue
    option = int(option)
    if option < 1 or option > 5:
        print("Sorry, this option does not exist.")
        print(available_options)
        continue

    print()
    if option == 1:
        input_and_add_recipe()
    elif option == 2:
        del_recipe(None)
    elif option == 3:
        print_recipe(None)
    elif option == 4:
        for key in cookbook.keys():
            print_recipe(key)
            print("")
    elif option == 5:
        print("Cookbook closed. Goodbye !")
        break
