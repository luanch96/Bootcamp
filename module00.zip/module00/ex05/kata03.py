kata = "The right format"

n = len(kata)
print(f"{(42 - n) * '-'}{kata}", end="")
