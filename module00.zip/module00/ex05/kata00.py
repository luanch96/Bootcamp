kata = (19, 42, 21)
print(f"The {len(kata)} numbers are: {', '.join(map(str, kata))}")
