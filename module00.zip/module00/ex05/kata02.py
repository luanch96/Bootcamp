from datetime import datetime

kata = (2019, 9, 25, 3, 30)
dt = datetime(*kata)
print(dt.strftime("%m/%d/%Y %H:%M"))
