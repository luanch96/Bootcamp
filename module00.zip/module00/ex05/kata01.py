kata = {
    "Python": "Guido van Rossum",
    "Ruby": "Yukihiro Matsumoto",
    "PHP": "Rasmus Lerdorf",
}

for key, val in kata.items():
    print(f"{key} was created by {val}")
